# Ithaca Quant v3.2.6 — delisted-stock evidence audit

The new `scripts/build_delisting_register.py` builds an SEC Form 25/15 evidence register and audits missing delisting outcomes. This DOES NOT supply complete delisted-stock histories and does not remove survivorship bias from Yahoo Finance. See `DELISTED_STOCK_HISTORY_v3.2.6.md`.

# Free historical market data (v3.2.5)

**No paid market-data subscription is required for the new free research pipeline.** Normal rankings use Yahoo Finance daily prices, and when `SEC_CONTACT_EMAIL` is set, up to 12 selected symbols can gain dated SEC EDGAR companyfacts features (conservatively available from the next business session). Build a private reusable Yahoo/SEC source snapshot with:

```bash
python scripts/acquire_free_history.py --tickers AAPL,MSFT,GOOGL,NVDA,AMZN --years 12 --out .ithaca_free_history
```

See [FREE_HISTORICAL_DATA_v3.2.5.md](FREE_HISTORICAL_DATA_v3.2.5.md) for SEC and optional `ITHACA_FREE_HISTORY_DIR` setup and all historical-universe warnings. **This is an incomplete survivor-selected free research sample, not a full point-in-time market archive; delisting settlements are not invented.**

---

## v3.2.4 — Private archived historical data connected to production

Configure `ITHACA_HISTORICAL_ARCHIVE_PATH` to the path of a **server-private licensed historical archive**. Live market data remains necessary for the latest observation, but archived point-in-time equity histories (including delisted names) are now used for model training. If the private dataset has missing terminal returns, the forecast fails closed rather than silently retraining on surviving Yahoo stocks. See `HISTORICAL_PRODUCTION_GUIDE_v3.2.4.md`.

**DATA STATUS:** No subscription credentials or complete institutional dataset were available in the build environment, so no authenticated market records are bundled. This is a functioning integration and settlement-label converter, not a replacement for obtaining the real data.

## v3.2.3 — Real historical-data acquisition

The application now includes `scripts/acquire_historical_data.py` to download authentic
licensed Sharadar TICKERS, STOCKS, ACTIONS and SPY FUNDS histories, and to convert a
specified historical research window to Ithaca's existing point-in-time archive format.
Unlike the earlier ZIP importer, this acquires records from the real vendor when an
authorized `SHARADAR_API_KEY` is configured. The licensed records are **not** included
in the public GitHub repo, and no full historical universe or delisting settlement
accuracy can be certified without those records. See
`HISTORICAL_DATA_SOURCE_v3.2.3.md` for steps, coverage checks and limits.

## New in v3.2.2: audit repairs (recommended)

The current release fixes stale-price screening, incomplete weight validation,
raw-vs-adjusted Yahoo price propagation, and legacy cache migration. A true
point-in-time historical archive **still requires licensed, authenticated
security histories and delisting returns**. Yahoo's vendor `Close` may be
split-adjusted retroactively; it is *not* certified as the original tape.
These changes improve data integrity and crash prevention, **not proven
predictive performance**. See `RELEASE_NOTES_v3.2.2.md` and
`AUDIT_REPAIRS_v3.2.2.md`.

## New in v3.2: analyst-informed portfolio research

The saved **My portfolio** workspace now retrieves real third-party analyst consensus from Yahoo Finance (best effort), or Finnhub (with an authorized `FINNHUB_API_KEY`). It records the source, observation time, monthly ratings and buy/hold/sell coverage, and can show named brokerage upgrade/downgrade actions. It also runs a conservative hypothetical allocation study using two years of price data, covariance shrinkage, turnover/concentration penalties, a cash reserve, recent stock-model signals, and *small* analyst preference tilts. No orders are sent. Snapshot downloads allow provenance review. Recent ratings cannot be backdated as historical evidence; stale ratings and insufficient coverage receive no analyst tilt.

The preceding v3.1 historical archive checks remain intact, but **a complete, licensed and authenticated institutional historical database is not bundled**, and no live predictive edge has been established. See `RELEASE_NOTES_v3.2.md` and `ANALYST_PORTFOLIO_GUIDE_v3.2.md`.

## New in v3.1: historical data integrity

Ithaca now supports point-in-time historical market archive ZIPs with stable security identities, exact raw and adjusted closes, dated membership snapshots, documented delisting payoffs, and SEC filing-vintage data. **No complete authenticated stock database is bundled.** See `HISTORICAL_DATA_GUIDE_v3.1.md` and `RELEASE_NOTES_v3.1.md`.

## v3.0.0 — accuracy validation and model contest robustness

See [RELEASE_NOTES_v3.0.md](RELEASE_NOTES_v3.0.md). Historical and live accuracy remain unverified without authentic data.

## v2.9.0 — model arena / accuracy safeguards

For every current stock, **Ridge**, **Gradient Boosting**, and **Random Forest** are trained independently on matured historical returns. An independent **selection** period picks a contender; a later **untouched audit** period must confirm that contender beats a calibrated version of the existing ensemble in mean absolute SPY-relative forecast error. Only then is the corresponding stock's forecast replaced. All other stocks retain their previous ensemble forecast. At least twenty nonoverlapping mature historical windows in each evaluation block are required; having many ticker-level observations on a single date does not substitute for independent forecast periods. The Accuracy Lab displays all three model predictions, the audit winner, MAE, and evidence status. The older Forecast/Momentum/Risk values in the leaderboard remain descriptive scoring heuristics; they are *not* the three predictive models.

The hypothetical portfolio backtest now uses a next-session adjusted-close fill rather than the already-known signal close. Missing fills leave cash uninvested; this is still not a live executable simulation. Capped forecast logging samples the full distribution of model forecasts rather than only the most bullish tickers.

Historical backtests with a present-day Yahoo ticker list **remain exposed to survivorship bias** and are labeled UNVERIFIED. For strict point-in-time analysis, enable the strict historical-universe option in the Walk-forward tests tab, and upload an authentic archived dated membership CSV (columns `date,ticker,eligible,provenance`; `provenance=historical_archive`, one full snapshot per tested signal date). This option **rejects missing historical constituents, including delisted tickers without complete return histories**, rather than inventing their prices. The CSV claim of historical origin cannot be independently authenticated by the app. If you do not have complete archived data, keep the historical results exploratory and unverified.

Only predictions recorded between a market close and the **next** market-session close can qualify for forward validation. Backdated imports, old demonstration rows, and entries with unverifiable timestamps are still visible in the historical ledger but excluded from qualified live-performance metrics and weekly accuracy reporting. Database timestamps are not cryptographic attestations; live accuracy remains unknown until actual timely market observations mature and are scored. All market information is educational; no orders are placed.

## Ithaca Quant v2.8 — Model Zoo & independent rank challenges

The **Model Zoo** in Full-market Dashboard → Accuracy Lab compares baseline Ridge,
nonlinear histogram ranking, a fixed linear/nonlinear ensemble, and optional
LightGBM/XGBoost LambdaMART on *within-date* stock rankings. A challenger must
beat Ridge in a chronologically purged selection block **and** independently
replicate on a separate untouched audit block. Results never silently replace
existing production forecasts or rankings.

The optional *enhanced individual-stock forecast* can now also compare Huber
robust regression, RBF random-Fourier features, and median quantile boosting.
CatBoost uses a time-ordered training option. An InterpretML explainable
boosting candidate is available when explicitly requested by developers with
its optional package installed; it is not automatically trained on Community
Cloud. The holdout regression forecast range uses asymmetric observed residual
quantiles, which are not a guarantee of market coverage.

Only NumPy/scikit-learn implementations are required by the default package;
optional accelerated packages are documented in `requirements-optional-ml.txt`.
Do not install optional packages without checking Streamlit memory and provider
terms. This is a research upgrade and **not** evidence of improved future returns.

---

## New in v2.5.5: Public Insider Activity (SEC Form 4)

The **🧾 SEC Form 4 Insider Activity** tab is immediately before **🏆 Ranked leaderboard** in the Full-Market Dashboard. Select the top 25 modeled stocks, all modeled stocks, or custom ticker symbols; then press **Check next companies** to retrieve recent public ownership filings. Companies are checked in bounded batches to respect the SEC's access policy. Reported non-derivative purchases and sales are presented with links to original filings, insider names/roles, transaction and disclosure dates, shares, prices, and known transaction amounts. Multiple insiders buying is a research observation—not a guarantee of higher prices. Grants and option exercises are excluded from buy/sell totals. Public Form 4 disclosures typically lag the transaction. **Configure `SEC_CONTACT_EMAIL` in Streamlit Secrets** with an administrator's valid contact email. Fetching may be blocked or throttled; blank results never imply that all recent insider activity has been captured. Historic stock forecasts and trade recommendations are not altered by this new information panel.

## v2.5.4 new: early trend & ticker-search research colors

The stock explorer now displays prominent entry and exit flags that use the same news/forecast/52-week evaluation as the market leaderboard. The all-stock screener reserves up to one quarter of its modeling shortlist for **early price-turn profiles**, rather than filtering mostly for already-surging companies. Six new point-in-time price/52-week features are *eligible* for the model only if historical selection supports them. Read [RELEASE_NOTES_v2.5.4.md](RELEASE_NOTES_v2.5.4.md) for every rule, limitation, test and deployment step. These are unvalidated research screens, not proven trade signals.

## v2.5.3 newest features
- Every modeled stock in the filtered leaderboard now enters an automatic company-news queue, not only the top 12. A 60-second Streamlit fragment refreshes one bounded batch of up to 24 ticker searches; the app shows checked/total coverage and stays honest when feeds fail. This is not a guarantee of exhaustive media coverage or a background job after the app sleeps.
- One broad Google News RSS query per company searches across the providers indexed by Google News, without a fixed three-publisher list. Publisher attribution and original article links are preserved.
- Same-company, same-event stories are grouped using event type, keywords, named deal targets, quarter labels and publication proximity. Five reports about the same deal count as **one event**, but the list of reporting sources remains visible. This deduplication also applies to point-in-time historical news model features; the primary trained model does not gain an unvalidated news boost.
- High-ranked companies are refreshed on roughly a 15-minute cache; the remainder of the modeled universe is on a 24-hour cache to limit provider requests. News access may be restricted by rate limits and Streamlit Cloud restarts can clear local queue cache. PostgreSQL is not yet used for this specific news queue.


- Automatic current-news columns for every modeled leaderboard candidate (incremental batches, news-coverage status); no news-fetch button. Acquisition reactions can downgrade overextended entries without changing the underlying forecast.
- Separate **Entry signal** and **Exit signal** color-coded columns with detailed conditions and a review queue.
- Screenshot imports: free local OCR using `pytesseract` and system `tesseract-ocr` (`packages.txt`), optional AI Vision when API credentials are provided, editable drafts and explicit confirmation. Never assume market price is purchase price.
- Deploy **all** files together into your currently working folder; keep the Streamlit main path unchanged. See `DEPLOY_THIS_FIRST.md`.

# Ithaca Quant v2.5.1 — Color-coded leaderboard with acquisition/run-up caution

**New in v2.5.1:** The **🏆 Ranked stock leaderboard** now shows dark-green, green, yellow and red entry/exit research signals, explaining each status. A new "Prioritize entry readiness" checkbox (on by default) adjusts *screening order*, not the trained forecasts, when a stock recently surged. A dated acquisition headline, when checked manually, can trigger an additional possible-"priced in" caution. Headline checking is opt-in and limited to ten symbols per click to avoid repeatedly scanning news for thousands of stocks. See `RELEASE_NOTES_v2.5.1.md` for complete thresholds, test status, installation guidance, and limitations.

# Ithaca Quant v2.5.0 — Sign-in, Screenshot Import & Portfolio Signals

## v2.5.0 — Google sign-in option, screenshot-based trade entry, portfolio traffic lights (November 18, 2026)

**New:** Google OIDC sign-in can unlock one saved virtual portfolio per account without typing recovery codes. Proper persistence on Streamlit Cloud requires PostgreSQL; sign-in alone is insufficient. Existing recovery-code portfolios remain accessible until OIDC is activated and may be migrated once.

**New:** Upload an image of the virtual holdings screen. Optional OpenAI vision extraction creates an **editable draft**, not automatic transactions. Review original cost basis, shares, and dates before saving. This requires a separately configured `OPENAI_API_KEY` and may incur charges.

**New:** Dark green (STRONG ENTRY WATCH), green, yellow and red research labels use the actual ENTRY WATCH, WATCH / CONFIRM, WAIT and REVIEW EXIT rules, with colored table cells. Dark green is a **stricter unvalidated screen** requiring ≥6% modeled SPY-relative return, ≥70% modeled gain probability, ≤60% annualized volatility, and <=15% known holding weight. Neither dark green nor green is a buy instruction. Fresh forecasts and eligible price data are required for green or red. Full-market scan still isn't needed for portfolio monitoring.

See [`SETUP_SIGN_IN_AND_PHOTOS.md`](SETUP_SIGN_IN_AND_PHOTOS.md) for instructions and security notes.

## v2.3.0 — Private saved holdings, purchase prices, share counts and stock monitoring (November 16, 2026)

New **💼 My portfolio** workspace: record actual virtual purchases/sales (ticker, shares, fill price and date), track weighted-average cost, value, realized/unrealized returns and remaining cash without a marketwide scan; view headlines for all holdings, run saved ticker-by-ticker machine-learning forecasts, and monitor sell-review conditions. A private recovery code reopens a saved account; **PostgreSQL is needed for reliable persistence after Streamlit Cloud restarts**. No automatic trading, closed-browser push alerts or guaranteed forecasts. See [RELEASE_NOTES_v2.3.md](RELEASE_NOTES_v2.3.md) for exhaustive instructions, testing and limitations. Keep the recovery code and DB credentials private.

# Ithaca Quant v2.2.0 — Independent Accuracy Gates

## v2.2.0 — More honest model selection and accuracy diagnostics (November 14, 2026)

**Read [RELEASE_NOTES_v2.2.md](RELEASE_NOTES_v2.2.md)** for every implemented change, test results, measured limitations and the accuracy estimate. The major changes are independent scale-calibration/feature-selection periods, four-block enhanced-model comparison, an optional robust-MAE model, purged probability calibration with separately evaluated Brier, and date-block directional-lift intervals. The main forecast is not proven more accurate; do not mistake synthetic benchmark figures for live stock accuracy.

# Ithaca Quant v2.1.0 — Forecast Accuracy Refinements

## v2.1.0 — Accuracy refinements on the v2.0 platform (November 14, 2026)

**Read [RELEASE_NOTES_v2.1.md](RELEASE_NOTES_v2.1.md).** Adds robust training targets, out-of-sample forecast-scale calibration, a gated extended feature group (12-1 momentum, 52-week-high gap, beta, idiosyncratic volatility, skew, liquidity and same-day cross-sectional ranks), holdout-weighted probability blending, bad-tick sanitation, and an A/B benchmark (`scripts/accuracy_benchmark.py`). Set `ITHACA_LEGACY_MODEL=1` to reproduce v2.0 exactly. No claim of live accuracy is made; run the benchmark on your own universe.

# Ithaca Quant v2.0.0 — Integrated Accuracy, Data & Reliability Upgrade

## v2.0.0 — Ten integrated improvements (November 14, 2026)

**Read [RELEASE_NOTES_v2.0.md](RELEASE_NOTES_v2.0.md) for a detailed explanation of all ten workstreams**, their implementations, activation steps, data requirements and limits. New modules include `research_lab.py`, `forecast_audit.py`, `remote_store.py`, `macro.py`, `portfolio_stress.py`, `provider_health.py`, `earnings_expectations.py` and `news_events.py`. The browser-only fast scanner is preserved; individual research can opt into stronger candidate-model selection, empirical forecast ranges, timestamped news/earnings, and real forward-performance records. New Accuracy lab and Data & macro tabs are included.

**Cloud installation warning:** Upload the complete matching application folder (including the inner package) from this release. Optional scheduled workflow must be moved to the repo-root `.github/workflows/`. SQL/FRED/SEC credentials are optional and must be authorized, private and supplied by the application owner.

A local Python + Streamlit **educational research dashboard** for the Ithaca College
virtual $1,000,000 high-school investment competition. It does **not** place orders,
log in to StockTrak, or reliably predict prices.

## v1.4.2 — Repair partial-release startup crashes (November 12, 2026)

**The fix:** a v1.4.1 `app.py` imported `select_1d_display_window` from `ithaca_quant.explorer`. That name does not exist in the v1.4 version of `explorer.py`, so uploading the main app without the matching inner package can crash the Streamlit Cloud app at startup. This v1.4.2 ZIP contains a complete, matching set of both files and validates package versions before feature imports. If the chart/presentation import is still incompatible, the app shows an actionable deployment-error screen rather than a redacted `ImportError` traceback.

**Install:** Upload/replace **all** files from this ZIP's `ithaca_quant/` folder into the repo's existing `ithaca_quant/` folder—not just `app.py`. The paths to check are `ithaca_quant/app.py`, `ithaca_quant/ithaca_quant/__init__.py`, `ithaca_quant/ithaca_quant/explorer.py`, and `ithaca_quant/ithaca_quant/presentation.py`. Do not create another nested `ithaca_quant` folder. Commit all changes on `main`, then reboot the Streamlit deployment if needed. See [`RELEASE_NOTES_v1.4.2.md`](RELEASE_NOTES_v1.4.2.md).

**Verification:** 91 automated offline tests passed, including new import-integrity tests; ZIP validated. Live Streamlit Cloud and Yahoo/SEC feeds are not tested in this environment.

**What did not change:** forecasting math, news/SEC handling, price feeds, ranking, 1D chart bounds, and database behavior. This is a startup/deployment consistency fix, not a new prediction model.

## v1.4.1 — Chart and forecast usability (November 12, 2026)

**See [`RELEASE_NOTES_v1.4.1.md`](RELEASE_NOTES_v1.4.1.md) for the complete, detailed change-by-change description, tests, setup and limitations.**

- 1D x-axis is **fixed to 8:30 AM–4:00 PM Eastern**. Only today's real bars in that window are plotted; no midnight-to-evening padding or invented observations. Actual regular trading typically starts at 9:30 AM Eastern.
- Financial tables show currency amounts **with commas** (e.g., `$145,234,567,890`), percentages, EPS, readable filing dates, and `Not reported` for missing data. These are display-only transformations, with no effect on historical model inputs.
- **After the close**, the 1D intraday heuristic is **still disabled** to avoid fabricating a next-hours projection. However the 1D explorer additionally shows a **separate trained next-trading-session ML forecast**, assuming 0% future SPY movement solely for its hypothetical dollar-price illustration. This does not guarantee accuracy or a next-day trading signal.
- The 1D probability headline now prioritizes next-session gain probability rather than an extremely rare +20% single-day event, while maintaining the existing insufficient-data safeguards.
- Genuine daily-model errors display more diagnostic information and a **user-triggered retry** that clears relevant caches; the app does not repeatedly hammer providers automatically.
- The app identifies its release independently and warns if `app.py` and the imported package have mismatched versions, helping diagnose sites that show v0.5 despite newer features.
- **88 offline automated tests passed.** Live cloud deployment and Yahoo/SEC feeds have not been verified in this build environment.

## v1.4 — Cached whole-universe updates and accuracy-first evidence features

**See [`RELEASE_NOTES_v1.4.md`](RELEASE_NOTES_v1.4.md) for a detailed explanation of every implemented update, its actual mechanisms, timing, tests, trade-offs, setup, and limitations.**

- **Full-universe persistence:** compressed SQLite snapshots remember the latest NYSE/Nasdaq screener and adjusted daily price histories across local reruns/restarts. Full rescans are separate from incremental refreshes; cloud-hosted local storage may be wiped on restart.
- **20-minute active-screen refresh target:** for a cached universe, fetch overlapping recent sessions only; retain years of existing history. Detect substantial changed split-adjusted bars and perform targeted full-history reconciliation. Failed downloads leave original prices intact and flagged as stale.
- **5-minute deep-data checks:** full-market modeled shortlist refreshes only recent *completed* daily observations, excluding unclosed daily bars until 5:00 p.m. New York time. Model inputs are cached so identical history need not be retrained over and over. More frequent checks do **not** imply novel daily forecasts every five minutes.
- **Fast priority quotes:** opt-in auto quote panel offers 15, 30, 60 and 120-second refresh intervals; >25 symbols have a 60-second minimum. Auto-quote requests are OFF until enabled to avoid accidental load from hidden Streamlit tabs. Feeds may be delayed or rate limited. Web sessions do not run as always-on background workers.
- **2-minute news retrieval cache:** optional active-session automatic recheck of the single-ticker research view. Headline feeds remain best-effort, and major news can be missed.
- **SEC quarterly financials:** when the app owner configures `SEC_CONTACT_EMAIL`, the single-ticker explorer fetches dated official companyfacts and extracts available quarterly revenue, net income, year-over-year sales growth and margins. The model only uses them beginning the business day **after the actual filing date**. Without SEC access, current Yahoo quarterly financial figures may appear as *context only*; no unverified filing dates enter historical training.
- **Time-stamped news archive:** previously fetched headlines retain publication and actual **first-seen** timestamps in SQLite. They cannot be inserted retroactively into older model signals. A new installation has **no historical news-training dataset**; it must accumulate genuinely dated history first.
- **Accuracy gate:** candidate SEC and archived-news features must beat the price-only model on a chronologically separated training holdout (1% SEC improvement; 2% for news-containing options), and coverage thresholds must be met. Walk-forward validation remains separate. Better holdout error is **not** proof of future performance.
- **No unsupported news-driven main chart:** the solid/dotted charts now show the price/eligible-trained-evidence model, not the v1.3 unvalidated headline-word adjustment. Previous news, boom and risk *sensitivity scenarios* still appear as a clearly separated comparison.
- **1D chart preserved:** starts at today's first real intraday observation, never at midnight or yesterday's close. No valid future projection means no dotted extension.

**Recommended installation:** unzip the current package and replace files *inside* the `ithaca_quant` folder in your GitHub repo. Streamlit main file: `ithaca_quant/app.py`. Add optional administrator contact in **Streamlit Secrets**, never public GitHub:

```toml
SEC_CONTACT_EMAIL = "your-valid-app-admin-contact@example.org"
```

The value above is only a placeholder; SEC API requests require a valid administrator contact. The system uses no age-restricted brokerage access, does not place real trades, and cannot guarantee price-prediction accuracy.

## v1.3 — News-aware scenario explanations and precisely cropped 1D charts

**Read [`RELEASE_NOTES_v1.3.md`](RELEASE_NOTES_v1.3.md) for an explanation of every implementation change, its methods, and limitations.**

- Searching one ticker automatically fetches recent **dated, linked, attributed** headlines from Google News RSS indexed for Yahoo Finance, Fox Business and ABC News, when available. Duplicate, stale, future and undated items are filtered, then relevance and word polarity are summarized. Fetch is cached for 15 minutes.
- The **News explanation for every estimate** panel shows the model's original return forecast, a **bounded, non-validated** news sentiment adjustment, the hypothetical combined price endpoint, the original and scenario boom estimates, and a risk stress illustration. It also explains buy/sell review dates. If feeds fail, the adjustment is zero, not inferred optimism.
- In intraday 1D mode, only *today's* headlines (Eastern time) may influence the short-term dotted heuristic, by at most ±0.2%. The daily model's research probabilities are not hourly forecast probabilities.
- **The 1D x-axis starts at the first observed price of the day**, not midnight. It ends at the last observed price or a valid forecast endpoint, without blank evening hours or an excursion into tomorrow. Exact timestamps appear on hover.
- An **optional** OpenAI API-backed **headline explanation** can be generated using a server-side secret (`OPENAI_API_KEY`); never put keys in GitHub. The numeric news adjustments do not depend on this optional model call. The feature may incur charges.
- On **Full-market dashboard → Ranked leaderboard**, choose **Analyze top five with current news** for a five-stock scenario comparison and CSV export. It does not secretly rescore the entire exchange universe.
- This is **NOT** a news-trained predictive ML model. Current news is a transparent research scenario and must never be inserted retroactively into past backtests. The three scoring components and two-retry network limit remain intact.

## v1.2 — Historical range controls and horizon-specific forecast extensions

The instant stock explorer now makes the **historical range and the dotted
future extension correspond to the selected chart button**:

| Range | Observed history | Forecast extension |
|---|---|---|
| 1D | Today only, in **New York time**, starting at the first observed bar, with hourly x-axis labels and exact timestamps on hover | Up to next **2 market hours**, capped at the approximate 4pm ET regular-session close; heavily shrunk **intraday momentum heuristic**, not AI-trained for hourly predictions |
| 5D | **Last five observed trading sessions**, including today if available | **Next trading session** using the 1-session daily ML forecast |
| 1M | Last calendar month | **Next 5 trading sessions**, daily model trained for that horizon |
| 6M | Last six calendar months | **Next 20 trading sessions** |
| YTD | January 1 to latest trading data | **Next 20 trading sessions** |
| 5Y | Last five calendar years | **Next 60 trading sessions** |

The solid curve contains only observed prices. The **dotted line is a visual
connection between the last observed point and a single forecast endpoint**;
intermediate prices are *not* forecast or fabricated. The daily model predicts
SPY-relative returns, shown as an absolute-price illustration only after
assuming **0% future SPY return**. Event/boom odds shown for 1D are explicitly
those from the separate daily model (the 1D intraday heuristic provides no
calibrated hourly probabilities). Business-day future dates are approximations
and do not exclude exchange-specific market holidays.

**1D will not show a prior day's intraday prices as if they were today**. Before
market opening, on weekends/holidays, or when intraday provider data is
unavailable, the 1D chart is blank with an explanation. After the market closes,
the app does not show a fictitious next-hours forecast. When quotes are more
than 60 minutes stale, the hourly extrapolation is disabled. The provider may
delay quotes; the short-term projection is not validated for forecasting.

The three ranking-score components, two-retry app-level network limit, market
scanner, company news, risk dashboards, and virtual portfolio are preserved.

## Previously added in v1.1 — instant single-stock lookup and forecast charts

- **Search bar at the top:** Enter a ticker (for example `NVDA`, `RKLB`, or `AAPL`)
  and click **Search stock**. The **Instant stock explorer** processes **only that
  ticker plus SPY**, without waiting for the broad NYSE/Nasdaq scan or 600-stock
  shortlist. Initial Yahoo requests can still take some time; cached repeats are faster.
- **Six chart ranges:** `1D`, `5D`, `1M`, `6M`, `YTD`, `5Y`, with the newer v1.2
  precise windows and corresponding horizon extensions detailed above.
- **Dotted projection:** Observed prices are solid and the hypothetical forecast
  endpoint is dotted. Intermediate chart locations are not per-minute or per-day
  price forecasts. Longer-range daily ML models predict SPY-relative return
  and assume zero SPY return to illustrate an absolute-price endpoint.
- **Existing stock details:** Historical volatility, experimental boom estimate,
  risk budget, technical watch conditions, optional market cap and publisher
  headlines. Use **Load or refresh company details** for market cap metadata.
- **Full-market dashboard retained:** Switch workspaces at the top to run the
  existing broad scanner, rankings, portfolio and formal walk-forward reports.
- **Caution:** A single-ticker model uses a smaller training population than
  the marketwide model. It is experimental, may disagree with the leaderboard,
  and its boom estimate may be unavailable for insufficient event history.

**How to deploy:** Upload the new extracted project contents to your GitHub repo
without adding a second nested `ithaca_quant` folder. Keep Streamlit's main
file path `ithaca_quant/app.py` if that matches your repository layout.

## v1.0 release overview (November 2026)

**Ithaca Quant v1.0.0** is a versioned packaging and documentation release of the
working v0.8 research prototype. It does **not** introduce a newly trained or
proven-accurate forecasting model; forecasts, news and probabilities remain
experimental research tools. Previous features are preserved:

- **Search stock + news:** ticker search, historical chart, scenario-based price
  forecast where the ticker was modeled, historical risk estimates, review dates,
  experimental boom probability, sector, industry, market cap and links to recent
  Google News RSS articles indexed from Yahoo Finance, Fox Business and ABC News.
- **Ranked leaderboard:** multiple sorting methods, the three transparent
  Forecast/Momentum/Risk scoring components, industry and market-cap filters,
  news context overlay and downloadable CSV.
- **History and validation:** embargoed walk-forward tests, historical model
  performance versus baselines, calibration checks and clear sample-size warnings.
- **Marketwide screener and prices:** large NYSE/Nasdaq watchlist discovery;
  latest available Yahoo prices, and optional authorized Alpaca IEX quotes.
- **Virtual portfolio:** hypothetical $1,000,000 competition allocation and
  risk-management tools. It does not trade or sync actual StockTrak positions.

**Release safeguards:** at most 3 workers per supported task; at most 2 app-level
retries following an initial network request. Model outputs are not reliable
predictions of exact returns, price targets, or buy/sell dates. Headlines are
**not** fed into the historical ML training pipeline; optional headline scoring
is an unvalidated research overlay.

### Deploy to Streamlit Community Cloud (share with your team)

Upload the contents of the extracted `ithaca_quant` project folder to GitHub.
Do not upload `.venv`, credentials, `.env`, API keys or local SQLite caches.
For a repository named `ithaca-quant` with all application files inside a
subdirectory named `ithaca_quant`, configure Streamlit deployment like this:

- Repository: `YOUR_GITHUB_USERNAME/ithaca-quant`
- Branch: `main`
- Main file path: `ithaca_quant/app.py`

If `app.py` and `requirements.txt` are at the repository root instead, set the
main file path to `app.py`. If the deployment tool reports the repository does
not exist, verify GitHub authorization/visibility before changing file paths.

**Cloud hosting limits:** Full-market scans and large backtests can run out of
RAM or encounter rate limits on free hosting. Begin with a manual shortlist or
modest scan. Each browser session can use significant compute; this release
has no shared database and changes to virtual holdings are not synchronized
across users. Keep API credentials in Streamlit secrets, not public GitHub.

### Run the full regression tests

```bash
python -m pip install -r requirements.txt
python -m pytest -q
```

See `CHANGELOG.md` for release history and known limitations.

## Update your version on Mac

1. In the old Terminal app, press **Control+C** to stop Streamlit.
2. Rename the existing `~/Downloads/ithaca_quant` folder to `ithaca_quant_old`
   so the new files do not get merged with the old version.
3. Download the **latest release** ZIP and double-click it to extract a NEW `ithaca_quant` folder
   inside Downloads.
4. Open Terminal and enter these commands **one at a time**:

```bash
cd ~/Downloads/ithaca_quant
bash start_mac.command
```

5. Open **http://localhost:8501** in Chrome. Keep Terminal open while using the app.
   Python 3.11+ and internet access are required for the first install and real data.

If you receive `No such file or directory`, use Finder to confirm where the
new `ithaca_quant` folder was extracted. If another Streamlit app is running,
it may choose port 8502 instead of 8501; use the URL Terminal reports.

## NEW in v0.6: Measured historical accuracy next to each ranked stock

Go to **🏆 Ranked leaderboard** and click **🧪 Run historical validation and add evidence to rankings**. This evaluates your selected model against historical outcomes that were **not in the model's training labels at the time of each forecast**. You can also run the same test in **🧪 Walk-forward tests**. These tabs share results only when the universe, forecast horizon, model settings, and other test inputs match.

The leaderboard and **🔎 Stock rankings** now show:

- **OOS windows** — number of distinct, nonoverlapping historical decision dates observed for that stock. A single stock may have only 8–24 observations, even when the whole model has thousands of ticker-outcomes.
- **OOS direction hit** — how often the stock's predicted **SPY-relative** outperformance sign matched the realized positive/negative sign. It does NOT mean how often the stock price rose.
- **OOS forecast MAE** — historical absolute percentage-point error of the relative-return forecast. Compare it to **OOS zero-forecast MAE**, a deliberately basic benchmark which always predicts zero outperformance.
- **OOS boom Brier** — squared probability error for the user-selected +10/+15/+20/+30% closing-price event (lower is better). Compare to the **OOS boom baseline Brier** that uses only the event frequency known at each historical decision date.
- **OOS evidence** — `Not tested`, `Too few OOS windows`, `Boom model lagged baseline`, or `Preliminary; unverified live`. Even a positive preliminary score does **not** establish reliable live performance.

The **Walk-forward tests** tab now includes model-versus-baseline accuracy metrics and **reliability tables/plots** that group past probability forecasts by their expected event frequency and compare against the **observed** fraction of events. Use the dropdown to switch **boom** or **gain**. Download **all historical ticker-window predictions and actual outcomes as CSV** to audit the reported accuracy.

**How to interpret:** A 100% OOS direction hit across 3 windows is **not** reliable accuracy evidence. Less than 12 windows is explicitly flagged too sparse. Even 24 windows provide only *preliminary* evidence, and stocks tested in the same market window are correlated. The system **does not recalibrate current probabilities** from the historical chart or claim any specific stock's current probability is verified. It does not learn from future event outcomes when forming historical forecasts.

**Important limitations:** Current U.S. exchange listings and screened survivors are used for historical tests: delisted stocks are absent (**survivorship bias**). The backtest uses idealized historical adjusted closing prices, not replicable execution prices; it does not predict precise buy/sell timing. Repeatedly optimizing settings against these test windows invalidates their out-of-sample status; a genuinely untouched final set is needed before stronger claims.

**Suggested starting settings:** 5 historical years, 20 trading-day forecast, 10% boom threshold to get a less sparse event dataset, 8 test periods for an initial check, then 16–24 periods if performance allows. Large 600-stock scans with many tests can take significant CPU/RAM. It is fine to begin with 50–100 modeled stocks and expand.

## Included since v0.5: Industry, sector, and market capitalization

The **🏆 Ranked leaderboard**, **🔎 Stock rankings**, and **🌐 Marketwide screener**
now include **Industry** and **Market cap ($B)** columns where company details
are available. The leaderboard and marketwide screen also support:

- **Sector filters** (for example, Technology or Healthcare)
- **Industry filters** (for example, Semiconductors or Software)
- **Market-cap buckets**: Mega (>= $200B), Large ($10B–$200B), Mid ($2B–$10B),
  Small ($300M–$2B), Micro (< $300M), plus all/known-only
- Click the **Market cap ($B)** column header to sort the table by size.
- CSV exports include these extra company fields and the last profile retrieval timestamp.

**How to load the fields:** Go to **🏆 Ranked leaderboard**, select **Load details
for top** (10, 25, 50, or 100), then press **Load next missing/stale company
profiles**. Profiles are downloaded from Yahoo Finance one ticker at a time;
repeat the button to cover further modeled companies. The broad-screen tab has
its **own** button to load the next 10–100 company profiles from the much larger
screened list. Exchange directories provide names and exchange but **do not**
provide reliable industry or market capitalization, so those fields begin blank
until their company profiles are retrieved. Large runs may take some time or
encounter provider rate limits. Yahoo may lack industry/cap for some companies.

Downloaded company profiles are cached locally in
`.company_metadata_cache.sqlite3` in the project folder. Each profile is
rechecked after 24h upon pressing the load button. Values are **latest
available reference metadata, not streaming real-time prices or historical
point-in-time valuations**. The app does NOT use current market cap or industry
metadata as features in its historical prediction or backtesting pipeline
(which would introduce future-information leakage). Market cap and the profile's
`metadata_asof` timestamp are shown for transparency. If the provider fails,
fields remain blank instead of being guessed. Existing rankings, risk tools,
quote panel, and virtual portfolio continue to operate without metadata.

## Ranked stock leaderboard with numbered rankings

Go to the first dashboard tab, **🏆 Ranked leaderboard**. It ranks the stocks
that successfully completed the deeper ML analysis; it is **not** a ranking
of every exchange listing (the broad screen has its own numbered basic ranking).

- **Balanced (upside + risk)** (default): relative score = 55% forecast
  SPY-relative return percentile + 15% historical SPY-relative momentum
  percentile + 20% lower-volatility percentile + 10% model-agreement percentile.
- **Forecast upside**: highest predicted excess return over SPY first.
- **Risk-adjusted forecast**: excess-return prediction divided by (2% plus
  horizon historical volatility plus model disagreement). Research heuristic.
- **Boom probability (experimental)**: estimated close-to-close probability
  of reaching the configured 10/15/20/30% event threshold. An internal
  chronological holdout comparison is shown when available; predictions are
  *not* proven calibrated probabilities.
- **Relative momentum**: highest historical 20-session return vs SPY.

Limit the maximum allowed historical volatility, show only positive model
forecasts, select the number of displayed rows, inspect history vs SPY,
and export the leaderboard as CSV. A basic stock-price eligibility filter
excludes stocks priced at $5 or below.

**A research score out of 100 is strictly a comparative cross-sectional rank,
not a 100% probability of making money.** Rankings depend on the stocks
available and the filters chosen, and may change without price moves if the
candidate universe changes. The quotes overlay (optional; up to 50 symbols)
shows Yahoo's latest *available* quote with a timestamp; it may be delayed or
stale, and it does not retrain the end-of-day forecasts.

The **Marketwide screener** also now has an explicit numbered leaderboard
for every stock passing its simple price/liquidity screen. These broad-screen
ranks use a heuristic rather than AI predictions.

## A much larger U.S. stock universe

1. In the sidebar select **Yahoo Finance** and **Automatic NYSE + Nasdaq universe**.
2. Choose **Listings to scan**: 500, 1,500, 3,000 or **ALL available**.
   ALL attempts to scan every current candidate obtained from Nasdaq Trader's
   NYSE/Nasdaq listing files; actual data coverage depends on provider limits.
3. Choose **Stocks to model deeply** (50 to 600).
4. Press **Scan NYSE + Nasdaq stocks**. Downloading thousands of symbols may
   take minutes and sometimes fail due to provider rate limits. You can start
   with 500–1,500 stocks and 100–200 model candidates.
5. In **Marketwide screener**, browse/export ALL stocks that passed price and
   liquidity rules; an explicitly labeled shortlist receives ML forecasts.
6. In **Stock rankings**, analyze predictions and hypothetical boom probabilities
   on the deep-modeled shortlist. **A screening score is not an AI prediction.**

The broad scan:
- Downloads one year of daily prices in chunks of 75 symbols.
- Filters for stock price >$5, at least $1 million median daily dollar
  volume, and adequate historical coverage.
- Selects a mixed candidate shortlist using liquidity, momentum and volatility.
- Downloads 3–8 years of price history for those candidates and applies the
  existing walk-forward research pipeline.
- Limits ML training row counts to contain runtime and memory on a laptop.
- Caches current exchange listings for 12h, scans for 6h and deep price data for 8h.

The Nasdaq Trader symbol directories are *current listings*. Backtests using
this candidate selection have **survivorship and selection bias**, because they
exclude previously delisted stocks and the broad screen is based on recent
performance. **Do not interpret these backtests as unbiased evidence of an edge.**
The exchange list is a candidate universe, NOT an eligibility guarantee.
Verify any instrument against the actual StockTrak competition rules.

## NEW: Latest available prices (separate from forecast inputs)

Open **Latest prices** in the dashboard.

**Option A: Yahoo intraday** — no credential needed, up to 75 requested
symbols. It fetches the latest available 1-minute bars. Prices may be delayed,
stale, or missing. **Do not treat Yahoo intraday as a real-time execution feed.**

**Option B: IEX real-time latest trades (optional)** — read-only Alpaca Market Data
API. Requires appropriately authorized market-data credentials; never bypass
account permissions, eligibility, or age requirements. If you already have
permission, enter the API key/secret in the sidebar of the prices tab or set
`APCA_API_KEY_ID` and `APCA_API_SECRET_KEY` environment variables. The app only
calls `GET https://data.alpaca.markets/v2/stocks/snapshots?feed=iex` and does
not trade. Free IEX quotes cover **IEX only**, not consolidated U.S. exchange
prices; the most recent trade can still be old for less liquid securities.

Choose manual refresh or optional ~60-second refresh. The table displays
last traded price, bid/ask where available, source, precise UTC timestamp and
quote age. Quotes over 15 minutes old are flagged **STALE**. After hours or
weekends, quotes can be hours/days old even when the feed is real-time.

**Never substitute these raw intraday quotes for adjusted daily closes used
by the ML and portfolio simulation.** These differ after dividends and stock
splits; also signals are end-of-day research flags, not execution instructions.

## Existing features

- Two-model educational price/benchmark-relative return estimates (Random
  Forest and HistGradientBoosting), 10/20/40-session forecasts.
- Experimental probability of a positive return or 10/15/20/30% gain as of the
  chosen forecast horizon. NOT verified accurate or calibrated odds.
- Hypothetical entry/exit watch conditions and risk-budgeted example positions.
- Chronological, embargoed walk-forward backtests versus SPY and momentum.
  Includes boom-probability Brier score against a historical-frequency baseline.
- $1,000,000 virtual portfolio with 5–20 holdings, max 25% initial position,
  historical risk diagnostics and hypothetical P&L.
- CSV exports. **No actual investment recommendations or orders**.
- Synthetic demo mode for offline illustration only; demo predictions are
  completely fictional.

## Development and tests

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q
streamlit run app.py
```

Offline tests cover feature building, chronological training, backtests,
portfolio rules, NYSE/Nasdaq listing parsing, screening, batched downloads and
IEX quote parsing. The full interactive browser workflow and public API feeds
must still be verified on the user's computer with a working network.

### Project structure

```text
app.py                            Streamlit UI with version label
ithaca_quant/__init__.py          Version constant and package identity
ithaca_quant/config.py            Competition research constraints
ithaca_quant/universe.py          Exchange listing discovery + broad screen
ithaca_quant/data.py              Yahoo historical batch downloader + demo
ithaca_quant/quotes.py            Yahoo intraday and optional read-only IEX quotes
ithaca_quant/features.py          Technical feature panel
ithaca_quant/model.py             Two-model return forecasts
ithaca_quant/probability.py       Experimental event models
ithaca_quant/backtest.py          Historical walk-forward tests
ithaca_quant/signals.py           Risk-budget and entry/exit watch rules
ithaca_quant/portfolio.py         Virtual portfolio and historical risk
ithaca_quant/leaderboard.py       Explainable rank formulas, filters, display
ithaca_quant/metadata.py          Yahoo company details, 24-hour SQLite cache
ithaca_quant/news.py              Google News RSS / headline analysis overlay
ithaca_quant/search.py            Stock search / review-date scenarios
start_mac.command                 Setup/launch script
requirements.txt                  Python dependencies
tests/                            Offline regression tests
```

### Official reference documentation

- Nasdaq symbol-directory data definitions:
  https://www.nasdaqtrader.com/Trader.aspx?id=SymbolDirDefs
- Alpaca snapshot endpoint (read-only data):
  https://docs.alpaca.markets/us/reference/stocksnapshots-1
- Ithaca College competition information:
  https://www.ithaca.edu/academics/school-business/high-school-investment-competition

## Research limitations

Historical returns do not ensure future returns. Broad-market scanning and
trading signals are hypotheses, not guaranteed profitable trading strategies.
Yahoo's unofficial public endpoint can throttle or deliver incomplete data,
and may be unsuitable for scanning thousands of stocks regularly. Prices can
be adjusted or revised; snapshots are not execution prices. Free IEX quote
feeds cover only IEX, not all exchanges. This app does not provide a real
StockTrak holdings sync or automatic order execution.

## NEW in v0.7: 3 scoring agents and at most 2 app-level retries

- Exactly three **transparent ranking components**: **Forecast** (model-predicted SPY-relative upside),
  **Momentum** (relative strength vs SPY), and **Risk** (lower historical volatility and better model agreement).
  They are score components, **not three autonomous AI chat agents**. Their weights reproduce the previous
  Balanced score: Forecast 55%, Momentum 15%, Risk 30%. All three agent sub-scores appear in the Ranked leaderboard.
- Network requests are attempted **once, with at most two additional retries** for a failing request.
  This applies to Yahoo price-history batches, intraday quote batches, Nasdaq directory requests,
  and individual company profile requests. Alpaca IEX snapshot requests retry transient server failures,
  but do NOT retry invalid credentials or 429 rate limits.
- `yfinance.download(threads=3)` and the random forest `n_jobs=3` limit per-task concurrency.
  The launcher also caps major numerical libraries to 3 threads. These are per-operation bounds,
  not a promise about the behavior of third-party APIs, internal retries, OS threads, or multiple app sessions.
- Batches with no valid response after the retries are excluded; nothing is fabricated.
  Large universe scans may still take time and provider throttling may prevent full coverage.

## v0.8 — Stock search and public news

- New **Search stock + news** tab: enter a ticker and press Analyze stock. The historical adjusted-price chart works even for a stock outside the current ML universe (when Yahoo data is available). To obtain AI forecasts for that stock, include it in the trained universe and rerun the app.
- Shows a **scenario price target** derived from the model's SPY-*relative* forecast under an explicit 0% SPY return assumption, plus an uncalibrated volatility range. These are not verified absolute price forecasts.
- Shows historical volatility, experimental boom event estimate, risk-budgeted position sizing, sector, industry, and market cap (click Update company profile to fetch metadata).
- Shows **entry and exit REVIEW dates**, not predicted optimal trading dates. Dates are business-day approximations and do not account for market holidays.
- On-demand Google News RSS search restricted to Yahoo Finance, Fox Business, and ABC News publisher domains. Displays links, publication timestamps and source; some publishers/tickers may have no matches. Google News may change feeds or block requests.
- News context is an explicitly unvalidated keyword sentiment heuristic. Optional leaderboard news overlay is separate from the machine-learning model and historical backtests; it cannot establish news-driven predictive performance. To train on news properly, collect licensed, timestamped historical headlines and redo chronological out-of-sample validation.
- News cached 15 minutes. Existing maximum of 3 workers and 2 app-level retries remains. Never place secrets in public GitHub.


## v2.6.0 — Forecast accuracy tracker and Friday report

- **Weekly forecast scorecard:** Open **Accuracy lab**, where you can preview the weekly report, see how many original forecasts were actually resolved this week, and download the most recent saved report. All measured forecasts come from real, immutable forward predictions; a synthetic demo is not investment accuracy.
- **Automatic daily logging:** Also install `.github/workflows/ithaca-daily-forecasts.yml` at your repository root; it runs 5:20 PM ET on weekdays and logs 5- and 20-session predictions for up to 60 tickers from GitHub secret `ITHACA_REFRESH_TICKERS` (comma-separated). It shares the same persistent database as Streamlit and the Friday report. Market data and GitHub job scheduling can be delayed or unavailable.
- **Optional schedule:** Copy `.github/workflows/ithaca-weekly-report.yml` to the **root of your GitHub repository** (not inside your Streamlit app subfolder). This is designed for a Friday **5:45 PM America/New_York** execution and automatically adjusts EST/EDT. Scheduled delivery can be delayed by GitHub Actions.
- **Persistent database is required** for scheduled reports: set `ITHACA_DATABASE_URL` in Streamlit Secrets and in GitHub Actions Secrets to the same authorized PostgreSQL database. Without it, the app's local database is not shared with the scheduled job.
- **Optional email:** Set `ITHACA_REPORT_EMAIL_TO`, `ITHACA_SMTP_HOST`, `ITHACA_SMTP_USER`, `ITHACA_SMTP_PASSWORD`; optionally `ITHACA_SMTP_PORT` (default 465) and `ITHACA_REPORT_EMAIL_FROM` in **GitHub Actions Secrets**. This sends the weekly report by encrypted SMTP. No email is sent if these are absent. Use a legitimate address; never commit secrets.
- **Accuracy improvement gate:** The independent ranking challenger uses a purged training period, separate selection period, and untouched audit. It is not assumed to beat the existing model; the dashboard reports when it fails. 80% is not a target to game by suppressing difficult predictions. Any displayed confident-subset accuracy must include the number of predictions and the coverage.
- **Notifications:** The app displays in-app notifications about completed evaluations and report readiness while open. The weekly SMTP report is the opt-in way to receive the report when the browser is closed; browser push is not implemented.



## v2.7.0 Institutional-style Research Audit

Open **Full-market dashboard → Walk-forward tests**, run the historical backtest,
then open **🏛️ Research audit**. The audit evaluates the *frozen out-of-sample*
results with date-by-date rank information coefficient, top-vs-universe excess,
turnover, cost sensitivity, and a one-session-delayed price proxy. A data-quality
panel shows incomplete or suspicious histories. It does not improve or certify the
underlying numerical forecasts by itself. Run `python scripts/institutional_demo.py`
for an explicitly **synthetic** demonstration. See `RELEASE_NOTES_v2.7.md` for
competitor research, provenance, unsupported claims and deployment notes.


**v3.2.1 model-mode hotfix:** The single-stock and portfolio forecast screens default to the three-model tournament. The enhanced research lab is a mutually exclusive alternative, not an additive promotion option. See `RELEASE_NOTES_v3.2.1.md`.
